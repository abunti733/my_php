
<?php

$student_roll=$_SESSION['student_id'];


?>

<!-- <div class="row">
//     <div class="col-sm-12 col-md-12 col-lg-2 col-xl-2 col-xxl-2">
// ghgkh;lgkh;k;flfhk
//     </div>
//     <div class="col-sm-12 col-md-12 col-lg-10 col-xl-10 col-xxl-10">
// dfdflkgdlkgmlfk


//     </div>
// </div> -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/admin_dashboard.css">
	<link rel="stylesheet" href="css/style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>
</head>
<body>
    <div class="container">
    <div class="row">
    <div class="col-sm-12 col-md-12 col-lg-2 col-xl-2 col-xxl-2">
    <div class="nav_bar">
    <div class="img">
        <img src="admin/images/desktop-wallpaper-gojo-satoru-cool-anime-anime-artwork-android-anime-gojo-sataru.jpg" alt="">
        <samp>sarmin</samp>
    </div>





    <nav class="sidebar card">
    <ul class="nav flex-column" id="nav_accordion">
    <li class="nav-item has-submenu">
    
    <a class="nav-link list-group-item" href="" ><i class="fa fa-user"></i>Profile</a>
</li>	
        <li class="nav-item has-submenu">
						
        <a class="nav-link list-group-item" href="" style="padding:10px;"><i class='fas fa-graduation-cap'></i>Education </a>
    </li>	
    <li class="nav-item has-submenu">
						
		<a class="nav-link list-group-item" href="" style="padding:10px;"><i class="fa fa-clock-o" aria-hidden="true"></i>Attendance</a>
	</li>	

    <li class="nav-item has-submenu">
						
								<a class="nav-link list-group-item" href=""><i class="fa fa-phone" aria-hidden="true"></i>Contact</a>
							</li>	


                            <li class="nav-item has-submenu">
						
								<a class="nav-link list-group-item" href="" style="padding:10px;"><i class="fa fa-bars"></i>Course & Fees</a>
							</li>	
        
        <li class="nav-item has-submenu">
    
            <a class="nav-link list-group-item" href=""  style="padding:10px;"><i class="fa fa-bars"></i>Home  Work</a>
        </li>	
        <li class="nav-item has-submenu">
    
    <a class="nav-link list-group-item" href=""><i class="fa fa-address-card"></i>Payment</a>
</li>	
<li class="nav-item has-submenu">
    
    <a class="nav-link list-group-item" href=""><i class="fa fa-cog" aria-hidden="true"></i>Passwird</a>
</li>						
    </ul>
</nav>
</div>


        </div>

        <div class="col-sm-12 col-md-12 col-lg-10 col-xl-10 col-xxl-10">
        <div class="container">
            <h2 style="color:#13A89E; padding:5px;"><i class="fa fa-user" style="padding:3px;"></i>Student Personal Info Statistics Overview</h2>
          
           <div class="p-2" style="color:#13A89E; background:#f5f5f5;"><i class="fa fa-user" style="padding:3px;"></i> Personal Information</div>
          
          
        </div>

        
        
            </div>
    
    </div>
    
    
    
    
    
    </div>
</body>
</html>